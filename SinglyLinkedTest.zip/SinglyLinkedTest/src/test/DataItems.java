package test;

public class DataItems{

private int key;


public DataItems(int _key){
    this.key=_key;
    
}

public int getKey() {
    return key;
}


public String toString() {
    return "("+getKey()+")";
}

}
