package test;

public class LinkedList{

HeadNode head;

public LinkedList(){
    head = new HeadNode();
}

// insert node at the beginning of the list
public void insertNode(DataItems _data){
    Node newNode = new Node();
    newNode.setDataItems(_data);
    Node nextNode = head.getNextNode();
    head.setNextNode(newNode);
    newNode.setNextNode(nextNode);
}


public void deleteNode(){
    Node toBeDeletedNode = head.getNextNode();
    if(toBeDeletedNode!=null) {
        Node nextNode = toBeDeletedNode.getNextNode();
        head.setNextNode(nextNode);
        toBeDeletedNode.setNextNode(null);
    } else {
        System.out.println("No nodes to be deleted");
    }

}

// display all nodes data
public void displayList(){
    Node nodes = head.getNextNode();
    int i=1;
    while(nodes!=null) {
        DataItems data = nodes.getDataItems();
        System.out.println("Node "+(this.size()-i)+" : "+data.toString());
        nodes = nodes.getNextNode();
        i++;
    }
}



// delete a node at index
public void deleteNodeAtIndex(int _index){
    if(_index==0) {
        deleteNode();
    } else {
        Node prevNode = nodeAtIndex(_index-1);
        if(prevNode!=null) {
            Node targetNode = prevNode.getNextNode();
            Node nextNode = targetNode.getNextNode();
            targetNode.setNextNode(null);
            prevNode.setNextNode(nextNode);
        }
    }
}



// return node at particular index
private Node nodeAtIndex(int _index){
    if(_index<0) {
        return null;
    } else {
        Node nodes = head.getNextNode();
        int i=0;
        while(i<_index && nodes!=null) {
            nodes = nodes.getNextNode();
            i++;
        }
        return nodes;
    }
}

public void searchKey(int _key){
    
	System.out.println("Remove all element in the linkedlist that is great than a target value : "+_key);
	int i=0;
    DataItems data = dataAtNodeIndex(i);
    while(data!=null){
        if(data.getKey()> _key){
            
        	this.deleteNodeAtIndex(i);
        	data = dataAtNodeIndex(i);
        	i=0;
        }
        else{
        	i++;
        	data = dataAtNodeIndex(i);
        }
    }
}


//return data item at particular node
public DataItems dataAtNodeIndex(int _index){
 Node nodes = nodeAtIndex(_index);
 if(nodes!=null) {
 return nodes.getDataItems();
} else {
 return null;
}
}



// return the size of linked list
public int size() {
    int count=0;
    Node nodes = nodeAtIndex(count);
    while(nodes!=null) {
        nodes = nodeAtIndex(++count);
    }
    return count;
}

}
