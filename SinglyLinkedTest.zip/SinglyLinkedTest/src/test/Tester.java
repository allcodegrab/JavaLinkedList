package test;

public class Tester
{

	public static void main(String[] args)
	{
				
				// create new linked list
				LinkedList ll = new LinkedList();
				
				// insert 10 data to the list
				for(int i=0; i<10; i++)
				{
				    DataItems data = new DataItems(i);
				    ll.insertNode(data);
				}
				System.out.println("\n");
				
				// display the inserted data
				System.out.println("10 inserted datas are : \n");
				ll.displayList();
				System.out.println("\n");
				
				//Remove the tail element
				System.out.println("Remove the tail element from a linkedlist : \n");
				ll.deleteNode();
				ll.displayList();
				System.out.println("\n");
				
				
				//testing Remove all element in the linkedlist that is greater than a target value
				
				ll.searchKey(4);
				System.out.println("\n");
				ll.displayList();
				System.out.println("\n");
				
				System.out.println("Size of LinkedList is  :"+ll.size());
				


	  }


}

