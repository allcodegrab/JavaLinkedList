package test;

public class HeadNode{ 

	

	Node nextNode;

	public void setNextNode(Node _nextNode) {
	    nextNode=_nextNode;
	}

	public Node getNextNode() {
	    return nextNode;
	}

	}